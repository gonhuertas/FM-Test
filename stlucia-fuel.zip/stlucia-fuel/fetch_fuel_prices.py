"""Fetch St. Lucia government gasoline price announcements.

Polls the RSS feed at https://www.govt.lc/news/rss, identifies
petroleum-price articles, extracts the new retail prices using
BeautifulSoup (HTML table), with a Grok LLM fallback for prose-only
articles, and appends new rows to data/stlucia_fuel_prices.csv.

Usage:
    python fetch_fuel_prices.py            # poll RSS only
    python fetch_fuel_prices.py --backfill # also scrape 150+ historical articles

Run weekly via Task Scheduler or cron. Articles already in the CSV
(matched by URL) are skipped automatically.

Dependencies:
    pip install feedparser requests beautifulsoup4 openai
"""

import csv
import importlib.util
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import feedparser                          # RSS parsing
import requests                            # HTTP requests
from bs4 import BeautifulSoup              # HTML parsing

# ── Paths ─────────────────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).parent
DATA_DIR   = SCRIPT_DIR / "data"
OUTPUT_CSV = DATA_DIR / "stlucia_fuel_prices.csv"

# ── Source URLs ───────────────────────────────────────────────────────────────

RSS_URL    = "https://www.govt.lc/news/rss"
SEARCH_URL = "https://www.govt.lc/search/gasoline"
BASE_URL   = "https://www.govt.lc"

# ── Keyword filter ────────────────────────────────────────────────────────────
# Any article whose title or description contains at least one of these
# (case-insensitive) is treated as a fuel-price announcement.

FUEL_KEYWORDS = [
    "gasoline", "fuel", "petroleum", "petrol",
    "diesel", "kerosene", "fuel price",
]

# ── CSV schema ────────────────────────────────────────────────────────────────

CSV_FIELDS = [
    "article_date",        # YYYY-MM-DD of the government announcement
    "article_url",
    "article_title",
    "product",             # e.g. "Unleaded Gasoline", "Diesel", "Kerosene"
    "new_price_ec_gallon", # EC$ per gallon (string, empty if not reported)
    "new_price_ec_litre",  # EC$ per litre  (string, empty if not reported)
    "extraction_method",   # "table" or "llm"
]

# ── Grok / LLM credentials ────────────────────────────────────────────────────
# Loads grok_token from credentials.py — first from this directory,
# then from the sibling haiti-social/ folder where it already exists.

def _load_grok_token() -> str | None:
    candidates = [
        SCRIPT_DIR / "credentials.py",
        SCRIPT_DIR.parent / "haiti-social" / "credentials.py",
    ]
    for path in candidates:
        if path.exists():
            spec = importlib.util.spec_from_file_location("_creds", path)
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            token = getattr(mod, "grok_token", None)
            if token:
                return token
    return None

GROK_TOKEN = _load_grok_token()


# ── Helpers: CSV ──────────────────────────────────────────────────────────────

def load_seen_urls() -> set[str]:
    """Return the set of article URLs already stored in the CSV."""
    if not OUTPUT_CSV.exists():
        return set()
    with OUTPUT_CSV.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return {row["article_url"] for row in reader}


def append_rows(rows: list[dict]) -> None:
    """Append a list of row dicts to the CSV, creating it with a header if new."""
    if not rows:
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    write_header = not OUTPUT_CSV.exists()
    with OUTPUT_CSV.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)


# ── Helpers: date parsing ─────────────────────────────────────────────────────

def parse_article_date(date_str: str) -> str:
    """Convert site date string to YYYY-MM-DD, e.g. 'Monday, February 1, 2016'."""
    # Strip leading weekday if present
    clean = re.sub(r"^\w+,\s*", "", date_str.strip())
    for fmt in ("%B %d, %Y", "%b %d, %Y", "%d %B %Y"):
        try:
            return datetime.strptime(clean, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return date_str.strip()  # fallback: return as-is


def parse_pubdate(rfc822: str) -> str:
    """Convert RSS pubDate (RFC 822) to YYYY-MM-DD."""
    try:
        dt = datetime(*feedparser._parse_date(rfc822)[:6])
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return ""


# ── Helpers: keyword filter ───────────────────────────────────────────────────

def is_fuel_article(title: str, description: str) -> bool:
    text = (title + " " + description).lower()
    return any(kw in text for kw in FUEL_KEYWORDS)


# ── Price extraction: HTML table ──────────────────────────────────────────────

# Regex to pull a dollar amount (with or without EC prefix) from a string
_PRICE_RE = re.compile(r"\$?\s*(?:EC\s*)?([\d,]+\.?\d*)")


def _parse_price(text: str) -> str:
    """Return the first numeric price found in text, or ''."""
    m = _PRICE_RE.search(text.replace(",", ""))
    return m.group(1) if m else ""


def extract_prices_table(soup: BeautifulSoup) -> list[dict]:
    """
    Look for an HTML table inside the article body and extract
    product / new-price rows. Returns a list of partial row dicts
    (keys: product, new_price_ec_gallon, new_price_ec_litre).

    Expects a table with columns roughly:
        Product | Existing Price | New Price | Change
    but is tolerant of variations.
    """
    # The article body lives in div.newscontent > div.newsbody elements
    content = soup.find("div", class_="newscontent")
    if not content:
        return []

    tables = content.find_all("table")
    if not tables:
        return []

    rows_out = []
    for table in tables:
        rows = table.find_all("tr")
        if len(rows) < 2:
            continue

        # Identify which column index is "New Price"
        header_row = rows[0]
        headers = [td.get_text(" ", strip=True).lower() for td in header_row.find_all("td")]
        try:
            new_price_col = next(
                i for i, h in enumerate(headers) if "new" in h and "price" in h
            )
        except StopIteration:
            # No recognisable "New Price" column — skip this table
            continue

        product_col = 0  # product name is always the first column

        for tr in rows[1:]:
            cells = tr.find_all("td")
            if len(cells) <= new_price_col:
                continue

            product_text = cells[product_col].get_text(" ", strip=True)
            # Skip blank or separator rows
            if not product_text or product_text in (":", " ", ""):
                continue

            # New-price cell may contain two lines: per-gallon and per-litre
            price_cell_text = cells[new_price_col].get_text("\n", strip=True)
            price_lines = [ln.strip() for ln in price_cell_text.splitlines() if ln.strip()]

            gallon_price = ""
            litre_price  = ""
            for line in price_lines:
                ll = line.lower()
                if "gallon" in ll or "cylinder" in ll:
                    gallon_price = _parse_price(line)
                elif "litre" in ll or "liter" in ll:
                    litre_price = _parse_price(line)
                elif not gallon_price:
                    # Single-price lines go to gallon column by default
                    gallon_price = _parse_price(line)

            if gallon_price or litre_price:
                rows_out.append({
                    "product":             product_text,
                    "new_price_ec_gallon": gallon_price,
                    "new_price_ec_litre":  litre_price,
                    "extraction_method":   "table",
                })

    return rows_out


# ── Price extraction: LLM fallback ────────────────────────────────────────────

def extract_prices_llm(article_text: str, article_url: str) -> list[dict]:
    """
    Send the article text to Grok and ask it to return a JSON list of
    {product, new_price_ec_gallon, new_price_ec_litre} objects.
    Returns [] if credentials are unavailable or the call fails.
    """
    if not GROK_TOKEN:
        print("  [LLM] No Grok token found — skipping LLM fallback.")
        return []

    # Lazy import so the script works even if openai is not installed
    try:
        from openai import OpenAI
    except ImportError:
        print("  [LLM] openai package not installed — skipping LLM fallback.")
        return []

    client = OpenAI(
        api_key=GROK_TOKEN,
        base_url="https://api.x.ai/v1",
    )

    prompt = (
        "You are a data extraction assistant. The following is the text of a "
        "Saint Lucia government press release about petroleum product prices. "
        "Extract the NEW retail prices (not old/existing prices) for each product. "
        "Return a JSON array of objects with keys: "
        "product (string), new_price_ec_gallon (string, EC$ per gallon, or empty string), "
        "new_price_ec_litre (string, EC$ per litre, or empty string). "
        "Use only numbers for the price values (e.g. '9.72', not '$9.72'). "
        "If a unit is not mentioned, leave it empty. "
        "Return only the JSON array with no extra text.\n\n"
        f"Article URL: {article_url}\n\n"
        f"Article text:\n{article_text[:4000]}"  # cap to avoid token overrun
    )

    try:
        response = client.chat.completions.create(
            model="grok-3-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
        )
        raw = response.choices[0].message.content.strip()
        # Strip markdown code fences if present
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
        data = json.loads(raw)
        for item in data:
            item["extraction_method"] = "llm"
        return data
    except Exception as e:
        print(f"  [LLM] Extraction failed: {e}")
        return []


# ── Article fetching ──────────────────────────────────────────────────────────

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; StLucia-fuel-tracker/1.0)"}


def fetch_article(url: str) -> tuple[str, str, BeautifulSoup | None]:
    """
    Fetch an article page. Returns (article_date, article_title, soup).
    Returns ("", "", None) on error.
    """
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"  [HTTP] Failed to fetch {url}: {e}")
        return "", "", None

    soup = BeautifulSoup(resp.text, "html.parser")

    # Date: <span class="newsdate">
    date_tag  = soup.find("span", class_="newsdate")
    date_str  = parse_article_date(date_tag.get_text(strip=True)) if date_tag else ""

    # Title: <span class="newsheadline">
    title_tag = soup.find("span", class_="newsheadline")
    title_str = title_tag.get_text(strip=True) if title_tag else ""

    return date_str, title_str, soup


def process_article(
    url: str,
    fallback_date: str = "",
    fallback_title: str = "",
) -> list[dict]:
    """
    Fetch one article, extract prices, and return a list of fully-populated
    CSV row dicts. Returns [] if extraction yields nothing.
    """
    print(f"  Fetching: {url}")
    article_date, article_title, soup = fetch_article(url)

    # Use RSS metadata as fallback if the page lacks the date/title
    if not article_date:
        article_date = fallback_date
    if not article_title:
        article_title = fallback_title

    if soup is None:
        return []

    # Try table extraction first
    price_rows = extract_prices_table(soup)

    # Fall back to LLM if table extraction found nothing
    if not price_rows:
        print("  No table found — trying LLM extraction.")
        content_div = soup.find("div", class_="newscontent")
        article_text = content_div.get_text(" ", strip=True) if content_div else ""
        price_rows = extract_prices_llm(article_text, url)

    if not price_rows:
        print("  No prices extracted.")
        return []

    # Build full CSV rows
    return [
        {
            "article_date":        article_date,
            "article_url":         url,
            "article_title":       article_title,
            "product":             r.get("product", ""),
            "new_price_ec_gallon": r.get("new_price_ec_gallon", ""),
            "new_price_ec_litre":  r.get("new_price_ec_litre", ""),
            "extraction_method":   r.get("extraction_method", ""),
        }
        for r in price_rows
    ]


# ── RSS polling ───────────────────────────────────────────────────────────────

def poll_rss(seen_urls: set[str]) -> list[dict]:
    """
    Parse the RSS feed and process any fuel-price articles not yet in the CSV.
    Returns a flat list of CSV row dicts for all new articles.
    """
    print(f"Polling RSS feed: {RSS_URL}")
    feed = feedparser.parse(RSS_URL)
    new_rows: list[dict] = []

    for entry in feed.entries:
        url   = entry.get("link", "")
        title = entry.get("title", "")
        desc  = entry.get("summary", "")
        pub   = entry.get("published", "")

        if url in seen_urls:
            continue
        if not is_fuel_article(title, desc):
            continue

        print(f"\nNew fuel article: {title}")
        rows = process_article(url, fallback_date=parse_pubdate(pub), fallback_title=title)
        new_rows.extend(rows)

    return new_rows


# ── Backfill: scrape search results ──────────────────────────────────────────

def get_search_urls() -> list[str]:
    """
    Scrape https://www.govt.lc/search/gasoline and extract article URLs
    from the JSON data embedded in the page's JavaScript.
    Returns a list of full URLs.
    """
    print(f"Fetching search results: {SEARCH_URL}")
    try:
        resp = requests.get(SEARCH_URL, headers=HEADERS, timeout=30)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"Failed to fetch search page: {e}")
        return []

    # The site embeds article data as JSON inside a JS ResourceSummaryList call.
    # Pattern: ResourceSummaryList([{...}, {...}], ...)
    # We pull all "Url" values from those objects.
    urls = re.findall(r'"Url"\s*:\s*"(/news/[^"]+)"', resp.text)
    full_urls = [BASE_URL + u for u in urls]
    print(f"  Found {len(full_urls)} articles in search results.")
    return full_urls


def backfill(seen_urls: set[str]) -> list[dict]:
    """
    Pull all gasoline-search URLs and process any not yet in the CSV.
    This may take several minutes due to per-article HTTP requests.
    """
    urls = get_search_urls()
    new_rows: list[dict] = []
    for url in urls:
        if url in seen_urls:
            print(f"  SKIP (already logged): {url.split('/')[-1]}")
            continue
        rows = process_article(url)
        new_rows.extend(rows)
        seen_urls.add(url)  # prevent double-processing within this run
    return new_rows


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    do_backfill = "--backfill" in sys.argv

    seen_urls = load_seen_urls()
    print(f"CSV already contains {len(seen_urls)} logged article URL(s).")

    all_new_rows: list[dict] = []

    if do_backfill:
        print("\n--- BACKFILL MODE ---")
        all_new_rows.extend(backfill(seen_urls))
        # Also poll RSS for anything so recent it isn't in the search results yet
        all_new_rows.extend(poll_rss(seen_urls))
    else:
        all_new_rows.extend(poll_rss(seen_urls))

    if all_new_rows:
        append_rows(all_new_rows)
        print(f"\nAppended {len(all_new_rows)} row(s) to {OUTPUT_CSV}")
    else:
        print("\nNo new fuel-price articles found.")


if __name__ == "__main__":
    main()
