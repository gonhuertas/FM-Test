"""
haiti_dashboard_update.py
─────────────────────────
Reads your xAI search log Excel file and regenerates haiti_tracker.html
with the latest data injected into the DATA LAYER section.

Usage:
    python haiti_dashboard_update.py x_search_log.xlsx

Requirements:
    pip install pandas openpyxl

Optional (for live WTI prices):
    pip install fredapi
    Set env var FRED_API_KEY (free key at https://fred.stlouisfed.org/docs/api/api_key.html)
"""

import sys
import json
import re
import os
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path


# ── Config ────────────────────────────────────────────────────────────────────

TEMPLATE_PATH = Path(__file__).parent / "haiti_tracker.html"
OUTPUT_PATH   = Path(__file__).parent / "haiti_tracker.html"  # overwrites in place

# Max tweets to show in the tweet widget
MAX_TWEETS = 12

# Max delta items to show
MAX_DELTA = 6


# ── Helpers ───────────────────────────────────────────────────────────────────

def html_escape(s: str) -> str:
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;")
             .replace("'", "&#39;"))


def strip_bullet(s: str) -> str:
    """Remove leading bullet chars that the model sometimes adds."""
    return re.sub(r"^[\u2022\-\*]\s*", "", s.strip())


def fmt_date(d) -> str:
    if isinstance(d, str):
        d = datetime.fromisoformat(d)
    return d.strftime("%b %-d, %Y")


# ── Load Excel ────────────────────────────────────────────────────────────────

def load_excel(path: str) -> dict:
    return pd.read_excel(path, sheet_name=None)


# ── Extract tweets ────────────────────────────────────────────────────────────

def extract_tweets(quotes_df: pd.DataFrame, max_n: int = MAX_TWEETS) -> list[dict]:
    """
    Parse the Quotes sheet into tweet dicts for the widget.
    Picks the most recent batch (latest timestamp) and deduplicates.
    """
    if quotes_df.empty:
        return []

    # Sort by timestamp descending, take latest run's quotes first
    df = quotes_df.copy()
    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df = df.sort_values("Timestamp", ascending=False)

    tweets = []
    seen_bodies = set()

    for _, row in df.iterrows():
        raw = str(row["Quote"]).strip()
        ts  = row["Timestamp"]

        # Try to extract handle and body from the standard format
        # e.g.: "• @handle: 'text'" or "- @handle: \"text\""
        m = re.search(r"@(\w+)[^:]*:\s*[\"'\u2018\u2019\u201c\u201d](.+?)[\"'\u2018\u2019\u201c\u201d]", raw, re.S)
        if m:
            handle = "@" + m.group(1)
            body   = m.group(2).strip()
        else:
            # Fallback: use the whole string as body
            handle = "Unknown"
            body   = re.sub(r"^[\u2022\-\*\d\.]\s*", "", raw)[:300]

        # Deduplicate on first 60 chars of body
        key = body[:60].lower()
        if key in seen_bodies:
            continue
        seen_bodies.add(key)

        # Skip very short or obviously non-tweet entries
        if len(body) < 20:
            continue

        tweets.append({
            "handle": handle,
            "date":   fmt_date(ts),
            "body":   body,
        })

        if len(tweets) >= max_n:
            break

    return tweets


# ── Build delta list ──────────────────────────────────────────────────────────

def build_delta(runs_df: pd.DataFrame, max_n: int = MAX_DELTA) -> list[dict]:
    """
    Compares the two most recent runs and produces a delta list.
    Items are marked is_new=True if they appear only in the latest run.

    For now: takes highlights from the latest run and marks all as new.
    When you have multi-day data, compare against previous day's run.
    """
    if runs_df.empty:
        return []

    runs_df = runs_df.copy()
    runs_df["Timestamp"] = pd.to_datetime(runs_df["Timestamp"])
    runs_df = runs_df.sort_values("Timestamp", ascending=False)

    latest = runs_df.iloc[0]
    highlights_raw = str(latest.get("Highlights", ""))

    items = []
    for line in highlights_raw.split("\n"):
        line = strip_bullet(line)
        if len(line) < 15:
            continue
        items.append({"text": line, "is_new": True})
        if len(items) >= max_n:
            break

    return items


# ── Build consensus text ──────────────────────────────────────────────────────

def build_consensus(runs_df: pd.DataFrame) -> str:
    if runs_df.empty:
        return ""
    runs_df = runs_df.copy()
    runs_df["Timestamp"] = pd.to_datetime(runs_df["Timestamp"])
    latest = runs_df.sort_values("Timestamp", ascending=False).iloc[0]
    return str(latest.get("Consensus", "")).strip()


# ── Build header metadata ─────────────────────────────────────────────────────

def build_header(runs_df: pd.DataFrame) -> dict:
    if runs_df.empty:
        return {}
    runs_df = runs_df.copy()
    runs_df["Timestamp"] = pd.to_datetime(runs_df["Timestamp"])
    runs_df = runs_df.sort_values("Timestamp", ascending=False)

    latest_ts   = runs_df["Timestamp"].iloc[0]
    earliest_fr = pd.to_datetime(runs_df["From Date"]).min()
    latest_to   = pd.to_datetime(runs_df["To Date"]).max()

    return {
        "last_run": latest_ts.strftime("%Y-%m-%d %H:%M"),
        "window":   fmt_date(earliest_fr) + " – " + fmt_date(latest_to),
    }


# ── Fetch WTI from FRED (optional) ───────────────────────────────────────────

def fetch_wti_fred(days: int = 35) -> dict | None:
    """
    Fetch WTI spot price from FRED (series DCOILWTICO).
    Returns None if fredapi not installed or key not set.
    """
    api_key = os.environ.get("FRED_API_KEY")
    if not api_key:
        return None
    try:
        from fredapi import Fred
        fred = Fred(api_key=api_key)
        end   = datetime.today()
        start = end - timedelta(days=days)
        s = fred.get_series("DCOILWTICO", observation_start=start, observation_end=end)
        s = s.dropna()
        labels = [d.strftime("%-d %b") for d in s.index]
        prices = [round(float(v), 2) for v in s.values]
        latest = prices[-1]
        first  = prices[0]
        pct    = round((latest - first) / first * 100, 1)
        sign   = "+" if pct > 0 else ""
        return {
            "labels":    labels,
            "prices":    prices,
            "price_val": f"${latest:.2f}",
            "change":    f"{sign}{pct}% in {days} days",
            "note":      s.index[-1].strftime("%-d %b %Y") + " · USD/barrel",
        }
    except Exception as e:
        print(f"[WTI] FRED fetch failed: {e}")
        return None


# ── Inject into HTML ─────────────────────────────────────────────────────────

def inject(html: str, tweets: list, delta: list, consensus: str,
           header: dict, wti: dict | None) -> str:

    # ── Header metadata
    if header.get("last_run"):
        html = re.sub(r'id="h-last-run">[^<]*',
                      f'id="h-last-run">{html_escape(header["last_run"])}', html)
    if header.get("window"):
        html = re.sub(r'id="h-window">[^<]*',
                      f'id="h-window">{html_escape(header["window"])}', html)

    # ── WTI oil chart data
    if wti:
        oil_js = (
            f'const OIL_DATA = {{\n'
            f'  labels: {json.dumps(wti["labels"])},\n'
            f'  prices: {json.dumps(wti["prices"])}\n'
            f'}};'
        )
        html = re.sub(
            r'const OIL_DATA = \{.*?\};',
            oil_js, html, flags=re.S
        )
        html = re.sub(r'id="oil-price-val">[^<]*',
                      f'id="oil-price-val">{html_escape(wti["price_val"])}', html)
        html = re.sub(r'id="oil-change-val">[^<]*',
                      f'id="oil-change-val">{html_escape(wti["change"])}', html)
        html = re.sub(r'id="oil-note-val">[^<]*',
                      f'id="oil-note-val">{html_escape(wti["note"])}', html)

    # ── Tweet widget data
    if tweets:
        tweets_js = "const TWEETS = " + json.dumps(tweets, ensure_ascii=False, indent=2) + ";"
        html = re.sub(
            r'const TWEETS = \[.*?\];',
            tweets_js, html, flags=re.S
        )
        # Also update the first tweet shown in the static HTML fallback
        t0 = tweets[0]
        html = re.sub(r'id="tw-handle">[^<]*',
                      f'id="tw-handle">{html_escape(t0["handle"])}', html)
        html = re.sub(r'id="tw-body">[^<]*',
                      f'id="tw-body">{html_escape(t0["body"])}', html)
        html = re.sub(r'id="tw-date">[^<]*',
                      f'id="tw-date">{html_escape(t0["date"])}', html)
        html = re.sub(r'id="tw-counter">[^<]*',
                      f'id="tw-counter">1 / {len(tweets)}', html)

    # ── Delta list
    if delta:
        items_html = "\n".join(
            f'          <div class="delta-item{" is-new" if d["is_new"] else ""}">'
            f'{html_escape(d["text"])}</div>'
            for d in delta
        )
        html = re.sub(
            r'(<div id="delta-list">).*?(</div>)',
            f'\\1\n{items_html}\n        \\2',
            html, flags=re.S
        )

    # ── Consensus
    if consensus:
        html = re.sub(
            r'(<div class="consensus-text" id="consensus-text">).*?(</div>)',
            f'\\1\n          {html_escape(consensus)}\n        \\2',
            html, flags=re.S
        )

    return html


# ── Main ─────────────────────────────────────────────────────────────────────

def main(excel_path: str):
    print(f"[1/5] Loading {excel_path} ...")
    sheets = load_excel(excel_path)

    runs_df   = sheets.get("Runs",   pd.DataFrame())
    quotes_df = sheets.get("Quotes", pd.DataFrame())

    print("[2/5] Extracting tweets ...")
    tweets = extract_tweets(quotes_df)
    print(f"      → {len(tweets)} tweets")

    print("[3/5] Building delta and consensus ...")
    delta     = build_delta(runs_df)
    consensus = build_consensus(runs_df)
    header    = build_header(runs_df)

    print("[4/5] Fetching WTI oil prices ...")
    wti = fetch_wti_fred()
    if wti:
        print(f"      → latest WTI: {wti['price_val']}")
    else:
        print("      → FRED_API_KEY not set or fetch failed; keeping placeholder data")
        print("        (set FRED_API_KEY env var for live prices)")

    print("[5/5] Injecting into HTML ...")
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    updated  = inject(template, tweets, delta, consensus, header, wti)
    OUTPUT_PATH.write_text(updated, encoding="utf-8")

    print(f"\nDone. Open: {OUTPUT_PATH.resolve()}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python haiti_dashboard_update.py path/to/x_search_log.xlsx")
        sys.exit(1)
    main(sys.argv[1])
